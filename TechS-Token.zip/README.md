# TechS Token (TSD)

Este repositório contém o contrato inteligente para o token **TechS (TSD)**, desenvolvido para a BNB Smart Chain.

## Informações do Token

- **Nome:** TechS
- **Símbolo:** TSD
- **Supply Inicial:** 1.000 TSD
- **Blockchain:** BNB Smart Chain (BEP-20 padrão)

## Como Usar

1. Compile usando o Remix IDE.
2. Faça o deploy conectado à rede BNB Smart Chain.
3. Adicione o token manualmente na carteira MetaMask usando o endereço do contrato após o deploy.

## Licença

Este projeto está licenciado sob a licença MIT.